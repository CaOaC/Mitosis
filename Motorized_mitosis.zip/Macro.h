#pragma once
#define DIMSIZE 3
#define MAX_BONDS 15
#define THREADS_PERBLOCK 512
#define SMCOUNT 68
#define PI 3.1415926
#define SHORTDIS ((i - j > 4) && (i - j < 20))
#define LONGDIS ((i - j > 100) && (i - j < 200))
