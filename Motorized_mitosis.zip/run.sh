#!/bin/bash
#此参数用于指定运行作业的名称
#DSUB -n kick
#此处需要把“用户名”修改为用户的用户名，例如用户名为 gpuuser001 则此行
#DSUB -A root.bingxing2.gpuuser442 
#默认参数，一般不需要修改 
#DSUB -q root.default
#DSUB -l wuhanG5500
#跨节点任务不同类型程序 job_type 会有差异，请参考下文对应跨节点任务模板
#DSUB --job_type cosched
#此参数用于指定资源。如申请 6 核 CPU，1 卡 GPU，48GB 内存。
#DSUB -R 'cpu=10;gpu=10;mem=45000'
#此参数用于指定运行作业的机器数量。单节点作业则为 1 。
#DSUB -N 1
# 此参数用于指定日志的输出，%J 表示 JOB_ID。
#DSUB -e %J.out
#DSUB -o %J.out

module load cuda/11.3.0-gcc-4.8.5-oaa 
make -j8
for i in {0..9}
do
	./kickModel -ensemble $i &
done

